app.controller("mainCtrl",["$scope", "$timeout", "Math", function( $scope, $timeout, as){

     $scope.data = [0,1,2,3,4,5,6,7,8,9,88,77,66,55,44,33];

     $scope.page = 0;

     $scope.Next = function() {
           $scope.page +=10;
           if(($scope.page+10)>$scope.data.length)
           	$scope.nextIf = true;
     }
   

}]);