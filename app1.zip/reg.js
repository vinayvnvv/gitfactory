app.controller('regCtrl',  function($scope){

	console.log("EReg controller called");
	
})