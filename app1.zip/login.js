app.controller('loginCtrl', function($scope){

	console.log("login controller called");
	
})