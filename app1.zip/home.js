app.controller('homeCtrl', function($scope){

	console.log("hiome  controller called");
	
})